## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 6, fig.height = 4
)
library(esios2fd)
library(dplyr)
library(lubridate)

## ----zigzag-15min, eval=FALSE-------------------------------------------------
# var <- "Real_time_CO2_10355"
# df15 <- esios2csv(
#   var_names  = var,
#   years      = 2022,
#   api_key    = api_key,
#   resolution = "15min",
#   output_dir = "data_csv",
#   verbose    = TRUE
# ) %>%
#   read.csv2(stringsAsFactors = FALSE)
# 
# # Primeros valores
# head(df15)

## ----plot-zigzag, echo=FALSE, fig.cap="Patrón zigzag en 15-min",eval=FALSE----
# # Ejemplo generado (suponiendo df15 cargado previamente)
# plot(x = ymd_hms(df15$instant), y = as.numeric(df15$val), type = 'l')

## ----agregacion, eval=FALSE---------------------------------------------------
# df_h15 <- df15 %>%
#   mutate(
#     time = ymd_hms(instant, tz = "Europe/Madrid"),
#     hour = floor_date(time, "hour")
#   ) %>%
#   group_by(hour) %>%
#   summarise(total15 = sum(as.numeric(val)))
# 
# # Descarga horaria directa
# df1h <- esios2csv(
#   var_names  = var,
#   years      = 2022,
#   api_key    = api_key,
#   resolution = "hour",
#   output_dir = "data_csv",
#   verbose    = FALSE
# ) %>%
#   read.csv2(stringsAsFactors = FALSE) %>%
#   transmute(
#     hour = ymd_hms(instant, tz = "Europe/Madrid"),
#     total1h = as.numeric(val)
#   )
# 
# # Comprobación
# all.equal(df_h15$total15, df1h$total1h)

